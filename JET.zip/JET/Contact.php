<?php
$conn = mysqli_connect("localhost","root","","Online registration");
if (!$conn){
    die("database connection failed");

}
$Name =$_POST['Name'];
$Email =$_POST['Email'];
$Mobileno =$_POST['Mobileno'];
$Message =$_POST['Message'];




$sql="INSERT INTO reach (Name,Email,Mobileno,Message) VALUES ('$Name','$Email','$Mobileno','$Message')";
if (mysqli_query($conn,$sql)){
      header("Location:Yes.html");
   
    exit();}
else
    {"Error:".mysqli_error($conn);

}
mysqli_close($conn);

?>   
