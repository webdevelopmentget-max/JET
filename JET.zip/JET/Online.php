<?php
$conn = mysqli_connect("localhost","root","","Online registration");
if (!$conn){
    die("database connection failed");

}
$Name =$_POST['Name'];
$Contactnumber =$_POST['Contactnumber'];
$Course =$_POST['Course'];
$Address =$_POST['Address'];



$sql="INSERT INTO apply (Name,Contactnumber,Course,Address) VALUES ('$Name','$Contactnumber','$Course','$Address')";
if (mysqli_query($conn,$sql)){
    header("Location:Susses.html");
    exit();}
else
    {"Error:".mysqli_error($conn);

}
mysqli_close($conn);

?>   
